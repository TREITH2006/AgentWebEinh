//#region src/protocol/commands.ts
var COMMAND = {
	PING: "PING",
	GET_STATUS: "GET_STATUS",
	SET_BACKEND_URL: "SET_BACKEND_URL",
	PAIR: "PAIR",
	UNPAIR: "UNPAIR"
};
var COMMAND_NAMES = Object.values(COMMAND);
function isCommandMessage(value) {
	if (typeof value !== "object" || value === null) return false;
	const candidate = value;
	return typeof candidate.type === "string" && COMMAND_NAMES.includes(candidate.type) && typeof candidate.requestId === "string";
}
//#endregion
//#region src/protocol/events.ts
var EVENT = {
	STATUS_CHANGED: "STATUS_CHANGED",
	CONNECTION_CHANGED: "CONNECTION_CHANGED"
};
function createStatusChanged(status) {
	return {
		type: EVENT.STATUS_CHANGED,
		status
	};
}
function createConnectionChanged(status) {
	return {
		type: EVENT.CONNECTION_CHANGED,
		status
	};
}
function isConnectionChangedEvent(value) {
	if (typeof value !== "object" || value === null) return false;
	return value.type === EVENT.CONNECTION_CHANGED;
}
//#endregion
export { isCommandMessage as a, COMMAND as i, createStatusChanged as n, isConnectionChangedEvent as r, createConnectionChanged as t };
