import { i as COMMAND, r as isConnectionChangedEvent } from "../assets/events-BHN3TTnl.js";
//#region \0vite/modulepreload-polyfill.js
(function polyfill() {
	const relList = document.createElement("link").relList;
	if (relList && relList.supports && relList.supports("modulepreload")) return;
	for (const link of document.querySelectorAll("link[rel=\"modulepreload\"]")) processPreload(link);
	new MutationObserver((mutations) => {
		for (const mutation of mutations) {
			if (mutation.type !== "childList") continue;
			for (const node of mutation.addedNodes) if (node.tagName === "LINK" && node.rel === "modulepreload") processPreload(node);
		}
	}).observe(document, {
		childList: true,
		subtree: true
	});
	function getFetchOpts(link) {
		const fetchOpts = {};
		if (link.integrity) fetchOpts.integrity = link.integrity;
		if (link.referrerPolicy) fetchOpts.referrerPolicy = link.referrerPolicy;
		if (link.crossOrigin === "use-credentials") fetchOpts.credentials = "include";
		else if (link.crossOrigin === "anonymous") fetchOpts.credentials = "omit";
		else fetchOpts.credentials = "same-origin";
		return fetchOpts;
	}
	function processPreload(link) {
		if (link.ep) return;
		link.ep = true;
		const fetchOpts = getFetchOpts(link);
		fetch(link.href, fetchOpts);
	}
})();
//#endregion
//#region src/popup/popup.ts
var statusEl = document.getElementById("status");
var backendUrlEl = document.getElementById("backend-url");
var pairingCodeEl = document.getElementById("pairing-code");
var pairBtn = document.getElementById("pair");
var disconnectBtn = document.getElementById("disconnect");
var metaEl = document.getElementById("meta");
var errorLineEl = document.getElementById("error-line");
var linkStatus = document.getElementById("link-status");
var backendEdited = false;
function sendCommand(message) {
	return chrome.runtime.sendMessage(message).catch(() => void 0);
}
function render(state) {
	let pairing = "idle";
	let backendUrl = "";
	if (state) {
		pairing = state.pairing;
		backendUrl = state.backendUrl;
	}
	let text = "Status: checking…";
	let cls = "status";
	if (pairing === "paired") {
		text = "Status: paired";
		cls += " connected";
	} else if (pairing === "waiting") {
		text = "Status: waiting for the backend…";
		cls += " waiting";
	} else if (pairing === "rejected") {
		text = "Status: pairing rejected";
		cls += " rejected";
	} else if (pairing === "error") {
		text = "Status: connection error";
		cls += " error";
	} else if (state && !state.connected) {
		text = "Status: disconnected";
		cls += " error";
	} else if (pairing === "idle" && state?.connected) {
		text = "Status: connected, not paired";
		cls += " waiting";
	}
	if (statusEl) {
		statusEl.textContent = text;
		statusEl.className = cls;
	}
	if (backendUrlEl && backendUrl && !backendEdited) backendUrlEl.value = backendUrl;
	if (pairBtn) {
		pairBtn.disabled = pairing === "paired" || pairing === "waiting";
		pairBtn.textContent = pairing === "paired" ? "Paired" : "Pair browser";
	}
	if (disconnectBtn) disconnectBtn.disabled = pairing !== "paired";
	if (errorLineEl) errorLineEl.textContent = state?.lastError || (state?.pairing === "rejected" ? "That code was rejected. Enter a fresh one from the website." : "");
	if (metaEl) metaEl.textContent = state ? `backend: ${backendUrl}${state.browserId ? ` · browser: ${state.browserId}` : ""}` : "backend: unknown";
}
async function refresh() {
	const response = await sendCommand({
		type: COMMAND.GET_STATUS,
		requestId: `popup-status-${Date.now()}`
	});
	render(response?.ok && typeof response.payload === "object" && response.payload !== null ? response.payload : null);
}
function wire() {
	backendUrlEl?.addEventListener("input", () => {
		backendEdited = true;
	});
	backendUrlEl?.addEventListener("change", () => {
		backendEdited = true;
		const url = backendUrlEl.value.trim();
		if (!url) return;
		sendCommand({
			type: COMMAND.SET_BACKEND_URL,
			requestId: `popup-url-${Date.now()}`,
			payload: { url }
		});
	});
	pairBtn?.addEventListener("click", () => {
		const code = pairingCodeEl?.value.trim() ?? "";
		if (code.length < 8) return;
		sendCommand({
			type: COMMAND.PAIR,
			requestId: `popup-pair-${Date.now()}`,
			payload: { code }
		});
	});
	disconnectBtn?.addEventListener("click", () => {
		sendCommand({
			type: COMMAND.UNPAIR,
			requestId: `popup-unpair-${Date.now()}`
		});
	});
	chrome.runtime.onMessage.addListener((message) => {
		if (isConnectionChangedEvent(message)) render(message.status);
		return false;
	});
	refresh();
}
async function pingBackground() {
	if (!linkStatus) return;
	try {
		linkStatus.textContent = (await chrome.runtime.sendMessage({
			type: COMMAND.PING,
			requestId: `popup-${Date.now()}`
		}))?.ok ? "background: connected" : "background: no reply";
	} catch {
		linkStatus.textContent = "background: unavailable";
	}
}
wire();
pingBackground();
//#endregion
