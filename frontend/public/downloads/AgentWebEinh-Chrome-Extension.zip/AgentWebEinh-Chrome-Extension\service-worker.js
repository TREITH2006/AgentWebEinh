import { a as isCommandMessage, i as COMMAND, n as createStatusChanged, t as createConnectionChanged } from "./assets/events-BHN3TTnl.js";
//#region src/types/index.ts
var EXTENSION_NAME = "AgentWebEinh";
var EXTENSION_PHASE = "Phase 2C";
var EXTENSION_SUBTITLE = "Paired Browser Engine";
//#endregion
//#region src/protocol/errors.ts
function makeError(code, message) {
	return {
		code,
		message
	};
}
//#endregion
//#region src/protocol/browser-commands.ts
var BROWSER_COMMAND_NAMES = [
	"OPEN_URL",
	"CLICK",
	"TYPE",
	"SCROLL",
	"BACK",
	"NEW_TAB",
	"GET_PAGE",
	"SCREENSHOT",
	"STOP"
];
var SCROLL_DIRECTIONS = [
	"up",
	"down",
	"left",
	"right"
];
var TARGET_STRATEGIES = ["css"];
var MAX_SELECTOR_LENGTH = 1e3;
var MAX_TYPE_TEXT_LENGTH = 5e3;
var MAX_SCROLL_AMOUNT = 2e4;
function isBrowserCommandEnvelope(value) {
	if (typeof value !== "object" || value === null) return false;
	const candidate = value;
	return candidate.type === "BROWSER_COMMAND" && typeof candidate.requestId === "string" && "command" in candidate;
}
function isBrowserCommandName(value) {
	return typeof value === "string" && BROWSER_COMMAND_NAMES.includes(value);
}
function fail(error) {
	return {
		ok: false,
		error
	};
}
function parseHttpUrl(raw) {
	if (typeof raw !== "string" || raw.trim() === "") return null;
	let url;
	try {
		url = new URL(raw);
	} catch {
		return null;
	}
	if (url.protocol !== "http:" && url.protocol !== "https:") return null;
	return url.href;
}
function parseTarget(obj) {
	const source = obj.target !== void 0 ? obj.target : obj;
	if (typeof source !== "object" || source === null) return {
		ok: false,
		error: makeError("INVALID_INPUT", "Target must be an object with a selector")
	};
	const target = source;
	if (target.strategy !== void 0) {
		if (typeof target.strategy !== "string" || !TARGET_STRATEGIES.includes(target.strategy)) return {
			ok: false,
			error: makeError("UNSUPPORTED_OPERATION", `Target strategy "${String(target.strategy)}" is not supported yet (supported: css)`)
		};
	}
	if (typeof target.selector !== "string" || target.selector.trim() === "") return {
		ok: false,
		error: makeError("INVALID_INPUT", "Target selector must be a non-empty string")
	};
	if (target.selector.length > 1e3) return {
		ok: false,
		error: makeError("INVALID_INPUT", `Target selector exceeds ${MAX_SELECTOR_LENGTH} characters`)
	};
	return {
		ok: true,
		target: {
			strategy: "css",
			selector: target.selector
		}
	};
}
function parseBrowserCommand(value) {
	if (typeof value !== "object" || value === null) return fail(makeError("INVALID_COMMAND", "Command must be an object"));
	const obj = value;
	const name = obj.command;
	if (typeof name !== "string") return fail(makeError("INVALID_COMMAND", "Command is missing a \"command\" field"));
	if (!isBrowserCommandName(name)) return fail(makeError("INVALID_COMMAND", `Unknown command: ${name}`));
	switch (name) {
		case "OPEN_URL": {
			const url = parseHttpUrl(obj.url);
			if (url === null) return fail(makeError("INVALID_URL", "OPEN_URL requires an absolute http(s) URL"));
			return {
				ok: true,
				command: {
					command: "OPEN_URL",
					url
				}
			};
		}
		case "NEW_TAB": {
			if (obj.url === void 0 || obj.url === null) return {
				ok: true,
				command: { command: "NEW_TAB" }
			};
			const url = parseHttpUrl(obj.url);
			if (url === null) return fail(makeError("INVALID_URL", "NEW_TAB url must be an absolute http(s) URL"));
			return {
				ok: true,
				command: {
					command: "NEW_TAB",
					url
				}
			};
		}
		case "CLICK": {
			const parsed = parseTarget(obj);
			if (!parsed.ok) return parsed;
			return {
				ok: true,
				command: {
					command: "CLICK",
					target: parsed.target
				}
			};
		}
		case "TYPE": {
			const parsed = parseTarget(obj);
			if (!parsed.ok) return parsed;
			if (typeof obj.text !== "string") return fail(makeError("INVALID_INPUT", "TYPE requires a string \"text\" field"));
			if (obj.text.length > 5e3) return fail(makeError("INVALID_INPUT", `TYPE text exceeds ${MAX_TYPE_TEXT_LENGTH} characters`));
			return {
				ok: true,
				command: {
					command: "TYPE",
					target: parsed.target,
					text: obj.text
				}
			};
		}
		case "SCROLL":
			if (typeof obj.direction !== "string" || !SCROLL_DIRECTIONS.includes(obj.direction)) return fail(makeError("INVALID_INPUT", "SCROLL direction must be one of: up, down, left, right"));
			if (typeof obj.amount !== "number" || !Number.isFinite(obj.amount) || !Number.isInteger(obj.amount) || obj.amount < 1 || obj.amount > 2e4) return fail(makeError("INVALID_INPUT", `SCROLL amount must be an integer between 1 and ${MAX_SCROLL_AMOUNT}`));
			return {
				ok: true,
				command: {
					command: "SCROLL",
					direction: obj.direction,
					amount: obj.amount
				}
			};
		case "BACK": return {
			ok: true,
			command: { command: "BACK" }
		};
		case "GET_PAGE": return {
			ok: true,
			command: { command: "GET_PAGE" }
		};
		case "SCREENSHOT":
			if (obj.format !== void 0 && obj.format !== "jpeg" && obj.format !== "png") return fail(makeError("INVALID_INPUT", "SCREENSHOT format must be \"jpeg\" or \"png\""));
			return {
				ok: true,
				command: {
					command: "SCREENSHOT",
					format: obj.format ?? "jpeg"
				}
			};
		case "STOP": return {
			ok: true,
			command: { command: "STOP" }
		};
		default: return fail(makeError("INVALID_COMMAND", `Unknown command: ${name}`));
	}
}
//#endregion
//#region src/protocol/results.ts
function okResult(command, requestId, data) {
	return {
		success: true,
		command,
		requestId,
		timestamp: Date.now(),
		data
	};
}
function failResult(command, requestId, error) {
	return {
		success: false,
		command,
		requestId,
		timestamp: Date.now(),
		error
	};
}
//#endregion
//#region src/protocol/page-ops.ts
var MAX_PAGE_TEXT_CHARS = 15e3;
var PAGE_OP_TIMEOUT_MS = 1e4;
//#endregion
//#region src/browser/errors.ts
var BrowserCommandError = class extends Error {
	code;
	constructor(code, message) {
		super(message);
		this.code = code;
		this.name = "BrowserCommandError";
	}
	toBrowserError() {
		return makeError(this.code, this.message);
	}
};
function throwIfCancelled(token) {
	if (token.cancelled) throw new BrowserCommandError("CANCELLED", "Operation cancelled by STOP");
}
function toBrowserError(error) {
	if (error instanceof BrowserCommandError) return error.toBrowserError();
	if (typeof error === "object" && error !== null && "code" in error && "message" in error && typeof error.code === "string" && typeof error.message === "string") return error;
	return makeError("INTERNAL_ERROR", error instanceof Error ? error.message : String(error));
}
//#endregion
//#region src/browser/content-channel.ts
var CONTENT_SCRIPT_FILE = "content/content-script.js";
function isPageOpResponse(value) {
	if (typeof value !== "object" || value === null) return false;
	const candidate = value;
	if (candidate.ok === true) return "data" in candidate;
	if (candidate.ok === false) {
		const error = candidate.error;
		return typeof error === "object" && error !== null && typeof error.code === "string" && typeof error.message === "string";
	}
	return false;
}
async function sendToContentScript(tabId, request) {
	let lastError;
	for (let attempt = 0; attempt < 2; attempt++) {
		if (attempt === 1) try {
			await chrome.scripting.executeScript({
				target: { tabId },
				files: [CONTENT_SCRIPT_FILE]
			});
		} catch (error) {
			const message = error instanceof Error ? error.message : String(error);
			if (/permission|cannot access|chrome:\/\//i.test(message)) throw new BrowserCommandError("PERMISSION_FAILURE", `Content script injection denied for tab ${tabId}: ${message}`);
			throw new BrowserCommandError("CONTENT_SCRIPT_UNAVAILABLE", `Unable to inject content script into tab ${tabId}: ${message}`);
		}
		try {
			const response = await chrome.tabs.sendMessage(tabId, request);
			if (!isPageOpResponse(response)) throw new BrowserCommandError("CONTENT_SCRIPT_UNAVAILABLE", `Tab ${tabId} returned an invalid page-op response`);
			return response;
		} catch (error) {
			if (error instanceof BrowserCommandError) throw error;
			lastError = error;
		}
	}
	throw new BrowserCommandError("CONTENT_SCRIPT_UNAVAILABLE", `No content script responded in tab ${tabId}: ${lastError instanceof Error ? lastError.message : String(lastError)}`);
}
async function withTimeout(promise, timeoutMs, code) {
	let timer;
	const timeout = new Promise((_, reject) => {
		timer = setTimeout(() => reject(new BrowserCommandError(code, `Page operation timed out after ${timeoutMs}ms`)), timeoutMs);
	});
	try {
		return await Promise.race([promise, timeout]);
	} finally {
		if (timer !== void 0) clearTimeout(timer);
	}
}
/**
* Runs a PAGE_OP against a tab's content script. Ensures the content script
* is present (injecting it if needed), enforces a timeout and honours the
* cancellation token before/after the round trip.
*/
async function sendPageOp(tabId, op, payload, token, requestId) {
	throwIfCancelled(token);
	const response = await withTimeout(sendToContentScript(tabId, {
		type: "PAGE_OP",
		op,
		requestId,
		payload
	}), PAGE_OP_TIMEOUT_MS, "PAGE_NOT_READY");
	throwIfCancelled(token);
	if (!response.ok) throw new BrowserCommandError(response.error.code, response.error.message);
	return response.data;
}
//#endregion
//#region src/browser/tabs.ts
var POLL_INTERVAL_MS = 100;
var DEFAULT_SETTLE_TIMEOUT_MS = 15e3;
var URL_CHANGE_GRACE_MS = 1500;
function sleep(ms) {
	return new Promise((resolve) => setTimeout(resolve, ms));
}
function toTabInfo(tab) {
	if (tab.id === void 0) throw new BrowserCommandError("TAB_NOT_FOUND", "Tab has no id");
	return {
		tabId: tab.id,
		url: tab.url ?? "",
		title: tab.title ?? ""
	};
}
async function getActiveTab() {
	let tabs;
	try {
		tabs = await chrome.tabs.query({
			active: true,
			currentWindow: true
		});
	} catch (error) {
		throw new BrowserCommandError("TAB_NOT_FOUND", `Unable to query tabs: ${String(error)}`);
	}
	const tab = tabs[0];
	if (!tab || tab.id === void 0) throw new BrowserCommandError("TAB_NOT_FOUND", "No active tab is available");
	return tab;
}
async function getTab(tabId) {
	try {
		return await chrome.tabs.get(tabId);
	} catch {
		throw new BrowserCommandError("TAB_NOT_FOUND", `Tab ${tabId} no longer exists`);
	}
}
/**
* Waits until the tab is loading-complete after a navigation. When
* `initialUrl` is provided, also waits for the URL (or loading state) to
* change first so a still-settling previous page is not observed as final.
*/
async function waitForSettle(tabId, token, initialUrl, timeoutMs = DEFAULT_SETTLE_TIMEOUT_MS) {
	const deadline = Date.now() + timeoutMs;
	let navigationObserved = initialUrl === void 0;
	while (true) {
		throwIfCancelled(token);
		const tab = await getTab(tabId);
		if (!navigationObserved) {
			if (tab.url !== initialUrl || tab.status !== "complete") navigationObserved = true;
			else if (Date.now() > deadline - timeoutMs + URL_CHANGE_GRACE_MS && tab.status === "complete") navigationObserved = true;
		}
		if (navigationObserved && tab.status === "complete") return tab;
		if (Date.now() > deadline) throw new BrowserCommandError("PAGE_NOT_READY", `Tab ${tabId} did not settle within ${timeoutMs}ms`);
		await sleep(POLL_INTERVAL_MS);
	}
}
//#endregion
//#region src/browser/controller.ts
/**
* Executes validated browser commands against the local Chrome instance.
* Commands run one at a time on an internal queue; STOP cancels the active
* command's token and invalidates commands still waiting in the queue.
*/
var BrowserController = class {
	active = null;
	queue = Promise.resolve();
	stopGeneration = 0;
	execute(rawCommand, requestId) {
		const parsed = parseBrowserCommand(rawCommand);
		if (!parsed.ok) {
			const name = typeof rawCommand === "object" && rawCommand !== null && typeof rawCommand.command === "string" ? String(rawCommand.command) : "INVALID";
			return Promise.resolve(failResult(name, requestId, parsed.error));
		}
		const command = parsed.command;
		if (command.command === "STOP") return Promise.resolve(this.stop(requestId));
		const generation = this.stopGeneration;
		const run = async () => {
			if (generation !== this.stopGeneration) return failResult(command.command, requestId, {
				code: "CANCELLED",
				message: `${command.command} cancelled by STOP before it started`
			});
			const token = { cancelled: false };
			const action = {
				command: command.command,
				token,
				startedAt: Date.now()
			};
			this.active = action;
			try {
				const data = await this.dispatch(command, token, requestId);
				return okResult(command.command, requestId, data);
			} catch (error) {
				return failResult(command.command, requestId, toBrowserError(error));
			} finally {
				if (this.active === action) this.active = null;
			}
		};
		const result = this.queue.then(run, run);
		this.queue = result.then(() => void 0, () => void 0);
		return result;
	}
	stop(requestId) {
		this.stopGeneration += 1;
		const hadActiveAction = this.active !== null;
		if (this.active) this.active.token.cancelled = true;
		return okResult("STOP", requestId, {
			stopRequested: true,
			hadActiveAction
		});
	}
	async dispatch(command, token, requestId) {
		switch (command.command) {
			case "OPEN_URL": return this.openUrl(command.url, token);
			case "NEW_TAB": return this.newTab(command.url, token);
			case "BACK": return this.back(token);
			case "CLICK": return this.click(command.target, token, requestId);
			case "TYPE": return this.typeInto(command.target, command.text, token, requestId);
			case "SCROLL": return this.scroll(command.direction, command.amount, token, requestId);
			case "GET_PAGE": return this.getPage(token, requestId);
			case "SCREENSHOT": return this.screenshot(command.format, token);
			case "STOP": throw new BrowserCommandError("INTERNAL_ERROR", "STOP is handled outside dispatch");
		}
	}
	async openUrl(url, token) {
		const tab = await getActiveTab();
		throwIfCancelled(token);
		try {
			await chrome.tabs.update(tab.id, { url });
		} catch (error) {
			throw new BrowserCommandError("NAVIGATION_FAILURE", `Failed to navigate to ${url}: ${error instanceof Error ? error.message : String(error)}`);
		}
		return toTabInfo(await waitForSettle(tab.id, token, tab.url));
	}
	async newTab(url, token) {
		throwIfCancelled(token);
		let tab;
		try {
			tab = await chrome.tabs.create(url !== void 0 ? { url } : {});
		} catch (error) {
			throw new BrowserCommandError("NAVIGATION_FAILURE", `Failed to create tab: ${error instanceof Error ? error.message : String(error)}`);
		}
		if (tab.id === void 0) throw new BrowserCommandError("TAB_NOT_FOUND", "Created tab has no id");
		if (url !== void 0) return toTabInfo(await waitForSettle(tab.id, token));
		return toTabInfo(tab);
	}
	async back(token) {
		const tab = await getActiveTab();
		throwIfCancelled(token);
		try {
			await chrome.tabs.goBack(tab.id);
		} catch (error) {
			throw new BrowserCommandError("NAVIGATION_FAILURE", `Tab cannot go back (no history entry): ${error instanceof Error ? error.message : String(error)}`);
		}
		return toTabInfo(await waitForSettle(tab.id, token, tab.url));
	}
	async click(target, token, requestId) {
		const tab = await getActiveTab();
		const data = await sendPageOp(tab.id, "CLICK", { target }, token, `${requestId}:click`);
		const settled = await getTab(tab.id);
		return {
			target,
			url: data.url || settled.url || "",
			title: data.title || settled.title || ""
		};
	}
	async typeInto(target, text, token, requestId) {
		const tab = await getActiveTab();
		const data = await sendPageOp(tab.id, "TYPE", {
			target,
			text
		}, token, `${requestId}:type`);
		const settled = await getTab(tab.id);
		return {
			target,
			url: data.url || settled.url || "",
			title: data.title || settled.title || "",
			length: data.length
		};
	}
	async scroll(direction, amount, token, requestId) {
		const data = await sendPageOp((await getActiveTab()).id, "SCROLL", {
			direction,
			amount
		}, token, `${requestId}:scroll`);
		return {
			direction,
			amount,
			scrollX: data.scrollX,
			scrollY: data.scrollY
		};
	}
	async getPage(token, requestId) {
		const tab = await getActiveTab();
		const data = await sendPageOp(tab.id, "GET_PAGE", void 0, token, `${requestId}:get_page`);
		const bounded = data.text.slice(0, MAX_PAGE_TEXT_CHARS);
		return {
			tabId: tab.id,
			url: data.url,
			title: data.title,
			text: bounded,
			truncated: data.truncated || data.text.length > 15e3,
			headings: data.headings ?? [],
			elements: data.elements ?? []
		};
	}
	async screenshot(format, token) {
		const tab = await getActiveTab();
		throwIfCancelled(token);
		let dataUrl;
		try {
			dataUrl = await chrome.tabs.captureVisibleTab(tab.windowId, format === "png" ? { format: "png" } : {
				format: "jpeg",
				quality: 80
			});
		} catch (error) {
			throw new BrowserCommandError("SCREENSHOT_FAILURE", `Unable to capture the visible tab: ${error instanceof Error ? error.message : String(error)}`);
		}
		if (typeof dataUrl !== "string" || !dataUrl.startsWith("data:image/")) throw new BrowserCommandError("SCREENSHOT_FAILURE", "Capture returned no image data");
		throwIfCancelled(token);
		const comma = dataUrl.indexOf(",");
		const payloadLength = comma >= 0 ? dataUrl.length - comma - 1 : dataUrl.length;
		return {
			tabId: tab.id,
			url: tab.url ?? "",
			title: tab.title ?? "",
			format,
			dataUrl,
			byteLength: Math.floor(payloadLength * 3 / 4),
			capturedAt: Date.now()
		};
	}
};
//#endregion
//#region src/websocket/connection.ts
var DEFAULT_HEARTBEAT_MS = 2e4;
var DEFAULT_MAX_OUTBOX = 64;
var BASE_BACKOFF_MS = 1e3;
var MAX_BACKOFF_MS = 3e4;
/**
* A resilient WebSocket client for the AgentWebEinh bridge.
*
* Reconnects with exponential backoff (plus jitter) until told to disconnect,
* heartbeats while open, and keeps a bounded outbox so a result produced while
* the socket is reconnecting is not silently dropped.
*/
var WebSocketConnection = class {
	options;
	socket = null;
	state = "idle";
	reconnectAttempt = 0;
	reconnectTimer;
	heartbeatTimer;
	stopped = false;
	outbox = [];
	constructor(options) {
		this.options = options;
	}
	getState() {
		return this.state;
	}
	connect() {
		if (this.socket) return;
		this.stopped = false;
		this.open();
	}
	/** Permanently tears the connection down; does not reconnect. */
	disconnect() {
		this.stopped = true;
		if (this.reconnectTimer !== void 0) {
			clearTimeout(this.reconnectTimer);
			this.reconnectTimer = void 0;
		}
		this.clearHeartbeat();
		this.outbox = [];
		if (this.socket) {
			const socket = this.socket;
			this.socket = null;
			this.setState("closed");
			try {
				socket.close();
			} catch {}
		}
	}
	send(payload) {
		let text;
		try {
			text = JSON.stringify(payload);
		} catch {
			this.options.onError?.(/* @__PURE__ */ new Error("Unable to serialize message"));
			return;
		}
		if (this.state === "open" && this.socket?.readyState === WebSocket.OPEN) {
			this.socket.send(text);
			return;
		}
		if (this.outbox.length < (this.options.maxOutbox ?? DEFAULT_MAX_OUTBOX)) this.outbox.push(text);
	}
	setState(state) {
		this.state = state;
	}
	open() {
		this.setState("connecting");
		let socket;
		try {
			socket = new WebSocket(this.options.url);
		} catch (error) {
			this.onSocketError(error instanceof Error ? error : new Error(String(error)));
			return;
		}
		this.socket = socket;
		socket.onopen = () => this.onSocketOpen(socket);
		socket.onmessage = (event) => this.onSocketMessage(socket, event);
		socket.onclose = (event) => this.onSocketClose(event);
		socket.onerror = () => {};
	}
	onSocketOpen(socket) {
		if (socket !== this.socket) return;
		this.reconnectAttempt = 0;
		this.setState("open");
		this.flushOutbox();
		this.startHeartbeat();
		this.options.onOpen?.();
	}
	onSocketMessage(socket, event) {
		if (socket !== this.socket) return;
		let data;
		try {
			data = JSON.parse(String(event.data));
		} catch {
			return;
		}
		this.options.onMessage?.(data);
	}
	onSocketClose(event) {
		if (this.socket && this.socket.readyState !== WebSocket.CLOSING && this.socket.readyState !== WebSocket.CLOSED) return;
		this.clearHeartbeat();
		if (this.socket) {
			this.socket = null;
			this.setState("closed");
		}
		this.options.onClose?.(event);
		if (this.stopped) return;
		this.scheduleReconnect();
	}
	onSocketError(error) {
		this.options.onError?.(error);
		if (this.stopped) return;
		this.scheduleReconnect();
	}
	scheduleReconnect() {
		if (this.reconnectTimer !== void 0) return;
		const base = Math.min(BASE_BACKOFF_MS * 2 ** this.reconnectAttempt, MAX_BACKOFF_MS);
		const jitter = Math.floor(base * (.5 + Math.random() * .5));
		this.reconnectAttempt += 1;
		if (this.socket) {
			this.socket = null;
			this.setState("closed");
		}
		this.reconnectTimer = setTimeout(() => {
			this.reconnectTimer = void 0;
			if (!this.stopped) this.open();
		}, jitter);
	}
	startHeartbeat() {
		this.clearHeartbeat();
		this.heartbeatTimer = setInterval(() => {
			if (this.state === "open" && this.socket?.readyState === WebSocket.OPEN) try {
				this.socket.send(JSON.stringify({ type: "ping" }));
			} catch {}
		}, this.options.heartbeatMs ?? DEFAULT_HEARTBEAT_MS);
	}
	clearHeartbeat() {
		if (this.heartbeatTimer !== void 0) {
			clearInterval(this.heartbeatTimer);
			this.heartbeatTimer = void 0;
		}
	}
	flushOutbox() {
		if (this.state !== "open" || !this.socket) return;
		const queued = this.outbox;
		this.outbox = [];
		for (const text of queued) try {
			this.socket.send(text);
		} catch {
			this.outbox.push(text);
			return;
		}
	}
};
//#endregion
//#region src/websocket/bridge.ts
var STORAGE_KEY_BACKEND_URL = "backendUrl";
var STORAGE_KEY_PAIRING_CODE = "pairingCode";
var DEFAULT_BACKEND_URL = "ws://127.0.0.1:8001/api/browser/ws";
/**
* Links the WebSocket to the backend and the BrowserController back to it.
*
* Lifecycle:
* 1. ``start()`` loads the persisted backend URL + pairing code and connects.
* 2. When the socket opens with a code stored, ``{type: "pair"}`` is sent.
* 3. ``paired`` answers are stored for this socket; ``browser_command`` frames
*    run through ``BrowserController`` and the resulting ``BrowserResult`` is
*    sent back as ``browser_result`` with the matching ``action_id``.
* 4. A `stop` frame cancels the current action; a rejected code is cleared so
*    the socket does not reconnect on a broken credential forever.
*/
var WireBridge = class {
	connection = null;
	controller = new BrowserController();
	backendUrl = DEFAULT_BACKEND_URL;
	pairingCode = null;
	browserId = null;
	connectionId = null;
	pairingState = "idle";
	lastError = null;
	started = false;
	async start() {
		if (this.started) return;
		this.started = true;
		await this.loadSettings();
		this.connect();
	}
	async shutdown() {
		this.started = false;
		this.pairingState = "idle";
		this.browserId = null;
		this.connectionId = null;
		this.connection?.disconnect();
		this.broadcast();
	}
	getBackendUrl() {
		return this.backendUrl;
	}
	getBrowserId() {
		return this.browserId;
	}
	getPairingState() {
		return this.pairingState;
	}
	getLastError() {
		return this.lastError;
	}
	isPaired() {
		return this.browserId !== null && this.connectionId !== null;
	}
	async setBackendUrl(url) {
		const next = normalizeWsUrl(url) ?? this.backendUrl;
		if (next === this.backendUrl) return;
		this.backendUrl = next;
		await chrome.storage.local.set({ [STORAGE_KEY_BACKEND_URL]: this.backendUrl });
		this.resetPairing();
		this.connect();
	}
	async pair(code) {
		const normalized = code.trim().toUpperCase();
		if (!normalized) return;
		this.pairingCode = normalized;
		this.lastError = null;
		this.pairingState = this.connection?.getState() === "open" ? "waiting" : "idle";
		await chrome.storage.local.set({ [STORAGE_KEY_PAIRING_CODE]: this.pairingCode });
		if (this.connection?.getState() === "open") this.sendPair();
		else this.connect();
		this.broadcast();
	}
	async unpair() {
		this.pairingCode = null;
		this.browserId = null;
		this.connectionId = null;
		this.pairingState = "idle";
		await chrome.storage.local.remove(STORAGE_KEY_PAIRING_CODE);
		this.broadcast();
	}
	async clearError() {
		this.lastError = null;
		this.broadcast();
	}
	async loadSettings() {
		const stored = await chrome.storage.local.get([STORAGE_KEY_BACKEND_URL, STORAGE_KEY_PAIRING_CODE]);
		const rawUrl = stored[STORAGE_KEY_BACKEND_URL];
		if (typeof rawUrl === "string" && rawUrl.trim()) {
			const normalized = normalizeWsUrl(rawUrl);
			if (normalized) this.backendUrl = normalized;
		}
		const rawCode = stored[STORAGE_KEY_PAIRING_CODE];
		if (typeof rawCode === "string" && rawCode.trim()) this.pairingCode = rawCode.trim().toUpperCase();
	}
	resetPairing() {
		this.browserId = null;
		this.connectionId = null;
		this.pairingState = "idle";
	}
	connect() {
		this.connection?.disconnect();
		const connection = new WebSocketConnection({
			url: this.backendUrl,
			onOpen: () => this.onOpen(),
			onMessage: (data) => this.onMessage(data),
			onClose: () => this.onClose(),
			onError: () => this.onError()
		});
		this.connection = connection;
		connection.connect();
		this.broadcast();
	}
	sendPair() {
		if (!this.pairingCode) return;
		this.pairingState = "waiting";
		const name = chrome.runtime.getManifest().name ?? "AgentWebEinh";
		this.connection?.send({
			type: "pair",
			code: this.pairingCode,
			name,
			extension_id: chrome.runtime.id
		});
		this.broadcast();
	}
	onOpen() {
		if (this.pairingCode) this.sendPair();
		else this.broadcast();
	}
	onClose() {
		if (this.browserId) {
			this.browserId = null;
			this.connectionId = null;
			this.pairingState = "idle";
		}
		this.broadcast();
	}
	onError() {
		this.lastError = "Unable to reach the backend. Check the backend URL and that it is running.";
		this.broadcast();
	}
	onMessage(raw) {
		if (typeof raw !== "object" || raw === null) return;
		const message = raw;
		switch (message.type) {
			case "paired":
				this.onPaired(message);
				break;
			case "pong": break;
			case "browser_command":
				this.onBrowserCommand(message);
				break;
			case "stop":
				this.onStop(message);
				break;
			case "error": this.onServerError(message);
		}
	}
	onPaired(message) {
		this.browserId = typeof message.browser_id === "string" ? message.browser_id : null;
		this.connectionId = typeof message.connection_id === "string" ? message.connection_id : null;
		this.pairingState = this.browserId && this.connectionId ? "paired" : "error";
		this.lastError = null;
		this.broadcast();
	}
	onServerError(message) {
		const code = typeof message.code === "string" ? message.code : "error";
		const text = typeof message.message === "string" ? message.message : String(message.message ?? code);
		if (code === "pairing_rejected") {
			this.pairingState = "rejected";
			this.pairingCode = null;
			chrome.storage.local.remove(STORAGE_KEY_PAIRING_CODE);
		} else this.pairingState = "error";
		this.lastError = text;
		this.broadcast();
	}
	async onBrowserCommand(message) {
		const taskId = typeof message.task_id === "string" ? message.task_id : "";
		const actionId = typeof message.action_id === "string" ? message.action_id : "";
		const connectionId = typeof message.connection_id === "string" ? message.connection_id : "";
		if (!taskId || !actionId || connectionId !== this.connectionId) return;
		const result = await this.controller.execute(message.command, actionId);
		this.sendResult(taskId, actionId, result);
	}
	onStop(message) {
		const taskId = typeof message.task_id === "string" ? message.task_id : "";
		this.controller.execute({ command: "STOP" }, `stop:${taskId || "task"}:${Date.now()}`).catch(() => {});
	}
	sendResult(taskId, actionId, result) {
		const payload = {
			type: "browser_result",
			task_id: taskId,
			action_id: actionId,
			connection_id: this.connectionId,
			success: result.success
		};
		if (result.success) payload.data = result.data;
		else payload.error = result.error;
		this.connection?.send(payload);
	}
	broadcast() {
		const event = createConnectionChanged({
			connected: this.connection?.getState() === "open",
			pairing: this.pairingState,
			browserId: this.browserId,
			connectionId: this.connectionId,
			backendUrl: this.backendUrl,
			lastError: this.lastError
		});
		chrome.runtime.sendMessage(event).catch(() => {});
	}
};
function normalizeWsUrl(raw) {
	const trimmed = raw.trim();
	if (!trimmed) return null;
	let url;
	try {
		url = new URL(trimmed);
	} catch {
		return null;
	}
	if (url.protocol !== "ws:" && url.protocol !== "wss:") return null;
	if (!url.pathname || url.pathname === "/") url.pathname = "/api/browser/ws";
	return url.href.replace(/\/$/, "");
}
//#endregion
//#region src/background/service-worker.ts
var controller = new BrowserController();
var bridge = new WireBridge();
function buildStatus() {
	return {
		name: EXTENSION_NAME,
		phase: EXTENSION_PHASE,
		subtitle: EXTENSION_SUBTITLE,
		status: bridge.isPaired() ? "Paired" : "Ready",
		connection: bridge.isPaired() ? "ready" : "disconnected",
		timestamp: Date.now(),
		connected: bridge.isPaired(),
		paired: bridge.isPaired(),
		browserId: bridge.getBrowserId(),
		backendUrl: bridge.getBackendUrl(),
		pairing: bridge.getPairingState(),
		lastError: bridge.getLastError()
	};
}
async function handleCommand(message) {
	const base = {
		requestId: message.requestId,
		ok: true,
		type: message.type
	};
	switch (message.type) {
		case COMMAND.PING: return {
			...base,
			payload: {
				pong: true,
				timestamp: Date.now()
			}
		};
		case COMMAND.GET_STATUS: return {
			...base,
			payload: buildStatus()
		};
		case COMMAND.SET_BACKEND_URL: {
			const url = message.payload?.url;
			if (typeof url !== "string" || !url.trim()) return {
				...base,
				ok: false,
				error: "SET_BACKEND_URL requires a string \"url\" payload"
			};
			await bridge.setBackendUrl(url);
			return {
				...base,
				payload: { url: bridge.getBackendUrl() }
			};
		}
		case COMMAND.PAIR: {
			const code = message.payload?.code;
			if (typeof code !== "string" || !code.trim()) return {
				...base,
				ok: false,
				error: "PAIR requires a string \"code\" payload"
			};
			await bridge.pair(code);
			return {
				...base,
				payload: { pairing: bridge.isPaired() ? "paired" : "waiting" }
			};
		}
		case COMMAND.UNPAIR:
			await bridge.unpair();
			return {
				...base,
				payload: { paired: false }
			};
		default: return {
			...base,
			ok: false,
			error: `Unknown command: ${message.type}`
		};
	}
}
chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
	if (isCommandMessage(message)) {
		handleCommand(message).then(sendResponse).catch((error) => {
			sendResponse({
				requestId: message.requestId,
				ok: false,
				type: message.type,
				error: error instanceof Error ? error.message : String(error)
			});
		});
		return true;
	}
	if (isBrowserCommandEnvelope(message)) {
		controller.execute(message.command, message.requestId).then((result) => sendResponse(result)).catch((error) => {
			sendResponse(failResult("INTERNAL", message.requestId, {
				code: "INTERNAL_ERROR",
				message: error instanceof Error ? error.message : String(error)
			}));
		});
		return true;
	}
	return false;
});
chrome.runtime.onInstalled.addListener(() => {
	bridge.start();
	const status = buildStatus();
	chrome.runtime.sendMessage(createStatusChanged(status)).catch(() => {});
});
bridge.start();
console.log(`${EXTENSION_NAME} ${EXTENSION_PHASE}: service worker started`);
//#endregion
